# EchoV1-emotional-ai
Echo V1 is an intelligent, emotion-aware AI assistant that takes voice or text input, detects your mood and intent, and responds empathetically using Groq's LLaMA-3 and natural-sounding speech. Built with Python, Streamlit, and modern AI APIs, it's your virtual emotional companion.
